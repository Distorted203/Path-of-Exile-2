import os
import time
import threading
import socket
import sys
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
    QFileDialog,
    QSlider,
    QMessageBox,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon
import pygame
import json
from pystray import Icon, Menu, MenuItem
from PIL import Image, ImageDraw

CONFIG_FILE = "config.json"


class PoEChatMonitor:
    def __init__(self):
        self.chat_file = None
        self.sound_file = None
        self.last_position = 0
        self.monitoring = False
        self.notification_sound = None
        self.volume = 1.0

    def read_new_lines(self, file, last_position):
        file.seek(last_position)
        new_lines = file.readlines()
        new_position = file.tell()
        return new_lines, new_position

    def start_monitoring(self):
        if not self.chat_file or not self.sound_file or self.monitoring:
            return

        self.monitoring = True
        self.last_position = os.path.getsize(self.chat_file)

        # Initialize pygame mixer
        try:
            pygame.mixer.init()
            print("Pygame mixer initialized successfully.")
        except pygame.error as e:
            print(f"Failed to initialize pygame mixer. Error: {e}")
            QMessageBox.critical(
                None,
                "Mixer Initialization Error",
                f"Failed to initialize the audio mixer.\nError: {e}",
            )
            return

        self.load_notification_sound()

        def monitor():
            while self.monitoring:
                if os.path.exists(self.chat_file):
                    with open(self.chat_file, 'r', encoding='utf-8') as file:
                        current_size = os.path.getsize(self.chat_file)
                        if current_size < self.last_position:
                            self.last_position = 0

                        new_lines, self.last_position = self.read_new_lines(file, self.last_position)
                        for line in new_lines:
                            if "@from " in line.lower():
                                print(f"New message detected: {line.strip()}")
                                if self.notification_sound:
                                    self.notification_sound.play()
                                else:
                                    print("Notification sound not loaded.")

                time.sleep(0.5)

        self.monitoring_thread = threading.Thread(target=monitor, daemon=True)
        self.monitoring_thread.start()

    def stop_monitoring(self):
        if self.monitoring:
            self.monitoring = False
            if self.monitoring_thread:
                self.monitoring_thread.join()
            print("Monitoring stopped.")

    def load_notification_sound(self):
        if self.sound_file:
            try:
                # Ensure the mixer is initialized
                if not pygame.mixer.get_init():
                    pygame.mixer.init()

                self.notification_sound = pygame.mixer.Sound(self.sound_file)
                self.notification_sound.set_volume(self.volume)
                print(f"Sound loaded successfully: {self.sound_file} with volume {self.volume}")
            except pygame.error as e:
                print(f"Failed to load sound file: {self.sound_file}. Error: {e}")
                QMessageBox.critical(
                    None,
                    "Error Loading Sound",
                    f"Failed to load the selected sound file.\nError: {e}",
                )
                self.sound_file = None  # Reset the sound file to avoid further issues
        else:
            print("No sound file provided.")

    def set_volume(self, volume):
        self.volume = volume
        if self.notification_sound:
            self.notification_sound.set_volume(self.volume)
        print(f"Volume set to {self.volume}")


class MainWindow(QMainWindow):
    def __init__(self, chat_monitor):
        super().__init__()
        self.chat_monitor = chat_monitor
        self.tray_icon = None

        # Load saved config
        config = load_config()
        self.chat_monitor.chat_file = config.get("chat_file")
        self.chat_monitor.sound_file = config.get("sound_file")
        self.chat_monitor.set_volume(config.get("volume", 1.0) / 100)  # Default to full volume

        self.init_ui()

        # Update UI with loaded config
        if self.chat_monitor.chat_file:
            self.chat_file_label.setText(f"Log File: {os.path.basename(self.chat_monitor.chat_file)}")
        if self.chat_monitor.sound_file:
            self.sound_file_label.setText(f"Sound File: {os.path.basename(self.chat_monitor.sound_file)}")
        self.volume_slider.setValue(config.get("volume", 100))  # Default to full volume

        # Automatically enable or disable monitoring based on file presence
        if self.chat_monitor.chat_file and self.chat_monitor.sound_file:
            self.enable_monitoring()
        else:
            self.disable_monitoring()

    def init_ui(self):
        self.setWindowTitle("PoE2 Chat Alert")
        self.setWindowIcon(QIcon("icon.png"))  # Optional: Add your app icon
        self.setGeometry(100, 100, 400, 300)

        # Main layout
        layout = QVBoxLayout()
        central_widget = QWidget(self)
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

        # Dark Mode Styling
        self.setStyleSheet("""
            QMainWindow {
                background-color: #2d2d2d;
            }
            QLabel {
                color: white;
                font-size: 12px;
            }
            QPushButton {
                background-color: #4c4c4c;
                color: white;
                border: 1px solid #5a5a5a;
                padding: 5px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #5a5a5a;
            }
            QSlider::groove:horizontal {
                height: 6px;
                background: #5a5a5a;
            }
            QSlider::handle:horizontal {
                background: white;
                width: 10px;
                margin: -5px 0;
                border-radius: 5px;
            }
        """)

        # Labels and buttons
        self.status_label = QLabel("Status: Disabled", self)
        self.status_label.setStyleSheet("color: red; font-size: 14px;")
        layout.addWidget(self.status_label)

        self.chat_file_label = QLabel("Log File: Not Selected", self)
        layout.addWidget(self.chat_file_label)

        self.select_chat_file_button = QPushButton("Select Log File", self)
        self.select_chat_file_button.clicked.connect(self.select_chat_file)
        layout.addWidget(self.select_chat_file_button)

        self.sound_file_label = QLabel("Sound File: Not Selected", self)
        layout.addWidget(self.sound_file_label)

        self.select_sound_file_button = QPushButton("Select Sound File", self)
        self.select_sound_file_button.clicked.connect(self.select_sound_file)
        layout.addWidget(self.select_sound_file_button)

        # Volume Label and Slider
        self.volume_label = QLabel("Volume: 100", self)  # Default to 100
        layout.addWidget(self.volume_label)

        self.volume_slider = QSlider(Qt.Orientation.Horizontal, self)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(100)  # Default volume is 100
        self.volume_slider.valueChanged.connect(self.adjust_volume)
        layout.addWidget(self.volume_slider)

        self.enable_button = QPushButton("Enable", self)
        self.enable_button.clicked.connect(self.enable_monitoring)
        layout.addWidget(self.enable_button)

        self.disable_button = QPushButton("Disable", self)
        self.disable_button.clicked.connect(self.disable_monitoring)
        layout.addWidget(self.disable_button)

        # Set up system tray
        self.init_tray()

        # Minimize to tray on close
        self.setAttribute(Qt.WidgetAttribute.WA_QuitOnClose, False)
        self.closeEvent = self.minimize_to_tray

    def init_tray(self):
        """Initialize the system tray icon."""
        def on_quit():
            self.chat_monitor.stop_monitoring()
            self.tray_icon.stop()
            QApplication.quit()

        def on_show_window():
            self.bring_to_foreground()

        # Create the tray menu
        menu = Menu(MenuItem("Show Window", on_show_window), MenuItem("Quit", on_quit))

        # Create the tray icon
        icon_image = Image.new("RGB", (64, 64), "black")
        draw = ImageDraw.Draw(icon_image)
        draw.rectangle((16, 16, 48, 48), fill="white")

        self.tray_icon = Icon("PoE2 Chat Alert", icon_image, menu=menu)
        self.tray_icon.title = "PoE2 Chat Alert"
        threading.Thread(target=self.tray_icon.run, daemon=True).start()

    def minimize_to_tray(self, event):
        """Minimize the window to the system tray when the close button is clicked."""
        event.ignore()  # Prevent the default close behavior
        self.hide()

    def bring_to_foreground(self):
        """Bring the window to the foreground when another instance is opened."""
        self.showNormal()
        self.activateWindow()

    def select_chat_file(self):
        chat_file, _ = QFileDialog.getOpenFileName(self, "Select Log File")
        if chat_file:
            self.chat_monitor.chat_file = chat_file
            self.chat_file_label.setText(f"Log File: {os.path.basename(chat_file)}")
            config = load_config()
            config["chat_file"] = chat_file
            save_config(config)

    def select_sound_file(self):
        sound_file, _ = QFileDialog.getOpenFileName(self, "Select Sound File", "", "Audio Files (*.mp3 *.wav)")
        if sound_file:
            self.chat_monitor.sound_file = sound_file
            self.sound_file_label.setText(f"Sound File: {os.path.basename(sound_file)}")
            self.chat_monitor.load_notification_sound()
            config = load_config()
            config["sound_file"] = sound_file
            save_config(config)

    def enable_monitoring(self):
        """Enable log monitoring and update the status label."""
        self.chat_monitor.start_monitoring()
        self.status_label.setText("Status: Enabled")
        self.status_label.setStyleSheet("color: green;")

    def disable_monitoring(self):
        """Disable log monitoring and update the status label."""
        self.chat_monitor.stop_monitoring()
        self.status_label.setText("Status: Disabled")
        self.status_label.setStyleSheet("color: red;")

    def adjust_volume(self, value):
        """Adjust the volume and update the label."""
        volume = value / 100  # Convert to a 0.0–1.0 range
        self.chat_monitor.set_volume(volume)
        self.volume_label.setText(f"Volume: {value}")  # Update the displayed value
        config = load_config()
        config["volume"] = value
        save_config(config)


def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as file:
                config = json.load(file)
                print(f"Config loaded: {config}")
                return config
        except (json.JSONDecodeError, IOError) as e:
            print(f"Failed to load configuration. Error: {e}")
    # Default values if no config file exists
    return {"chat_file": None, "sound_file": None, "volume": 100}


def save_config(config):
    try:
        with open(CONFIG_FILE, "w") as file:
            json.dump(config, file, indent=4)  # Pretty-print JSON for easier debugging
        print(f"Config saved: {config}")
    except IOError as e:
        print(f"Failed to save configuration. Error: {e}")


if __name__ == "__main__":
    # Single-instance check using a socket
    server_address = ("127.0.0.1", 65432)  # Localhost and port
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind(server_address)
        server_socket.listen(1)
        print("No existing instance detected. Starting application.")

        app = QApplication([])
        chat_monitor = PoEChatMonitor()
        window = MainWindow(chat_monitor)
        window.show()

        # Focus listener to handle additional launches
        def focus_listener():
            while True:
                conn, _ = server_socket.accept()
                conn.close()
                window.bring_to_foreground()

        threading.Thread(target=focus_listener, daemon=True).start()
        app.exec()

    except OSError:
        print("Another instance detected. Sending focus request.")
        try:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect(server_address)
            client_socket.close()
        except ConnectionRefusedError as e:
            print(f"Failed to connect to the existing instance: {e}")
        sys.exit()

# Nabooru