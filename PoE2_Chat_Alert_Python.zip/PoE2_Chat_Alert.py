import os
import time
import threading
import socket
import sys
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
    QFileDialog,
    QSlider,
    QMessageBox,
)
from PyQt6.QtCore import Qt, QEvent
from PyQt6.QtGui import QIcon
import pygame
import json
from pystray import Icon, Menu, MenuItem
from PIL import Image, ImageDraw

CONFIG_FILE = "config.json"


class PoEChatMonitor:
    def __init__(self):
        self.chat_file = None
        self.sound_file = None
        self.last_position = 0
        self.monitoring = False
        self.notification_sound = None
        self.volume = 1.0

    def read_new_lines(self, file, last_position):
        file.seek(last_position)
        new_lines = file.readlines()
        new_position = file.tell()
        return new_lines, new_position

    def start_monitoring(self):
        if not self.chat_file or not self.sound_file or self.monitoring:
            return

        self.monitoring = True
        self.last_position = os.path.getsize(self.chat_file)

        try:
            pygame.mixer.init()
        except pygame.error as e:
            QMessageBox.critical(
                None,
                "Mixer Initialization Error",
                f"Failed to initialize the audio mixer.\nError: {e}",
            )
            return

        self.load_notification_sound()

        def monitor():
            while self.monitoring:
                if os.path.exists(self.chat_file):
                    with open(self.chat_file, 'r', encoding='utf-8') as file:
                        current_size = os.path.getsize(self.chat_file)
                        if current_size < self.last_position:
                            self.last_position = 0

                        new_lines, self.last_position = self.read_new_lines(file, self.last_position)
                        for line in new_lines:
                            if "@from " in line.lower():
                                if self.notification_sound:
                                    self.notification_sound.play()

                time.sleep(0.5)

        self.monitoring_thread = threading.Thread(target=monitor, daemon=True)
        self.monitoring_thread.start()

    def stop_monitoring(self):
        if self.monitoring:
            self.monitoring = False
            if self.monitoring_thread:
                self.monitoring_thread.join()

    def load_notification_sound(self):
        if self.sound_file:
            try:
                if not pygame.mixer.get_init():
                    pygame.mixer.init()
                self.notification_sound = pygame.mixer.Sound(self.sound_file)
                self.notification_sound.set_volume(self.volume)
            except pygame.error as e:
                QMessageBox.critical(
                    None,
                    "Error Loading Sound",
                    f"Failed to load the selected sound file.\nError: {e}",
                )
                self.sound_file = None

    def set_volume(self, volume):
        self.volume = volume
        if self.notification_sound:
            self.notification_sound.set_volume(self.volume)


class MainWindow(QMainWindow):
    def __init__(self, chat_monitor):
        super().__init__()
        self.chat_monitor = chat_monitor
        self.tray_icon = None

        config = load_config()
        self.chat_monitor.chat_file = config.get("chat_file")
        self.chat_monitor.sound_file = config.get("sound_file")
        self.chat_monitor.set_volume(config.get("volume", 1.0) / 100)

        self.init_ui()

        if self.chat_monitor.chat_file:
            self.chat_file_label.setText(f"Log File: {os.path.basename(self.chat_monitor.chat_file)}")
        if self.chat_monitor.sound_file:
            self.sound_file_label.setText(f"Sound File: {os.path.basename(self.chat_monitor.sound_file)}")
        self.volume_slider.setValue(config.get("volume", 100))

        if self.chat_monitor.chat_file and self.chat_monitor.sound_file:
            self.enable_monitoring()
        else:
            self.disable_monitoring()

    def init_ui(self):
        self.setWindowTitle("PoE2 Chat Alert")
        self.setWindowIcon(QIcon("icon.png"))
        self.setGeometry(100, 100, 400, 300)

        layout = QVBoxLayout()
        central_widget = QWidget(self)
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

        self.setStyleSheet("""
            QMainWindow {
                background-color: #2d2d2d;
            }
            QLabel {
                color: white;
                font-size: 12px;
            }
            QPushButton {
                background-color: #4c4c4c;
                color: white;
                border: 1px solid #5a5a5a;
                padding: 5px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #5a5a5a;
            }
            QSlider::groove:horizontal {
                height: 6px;
                background: #5a5a5a;
            }
            QSlider::handle:horizontal {
                background: white;
                width: 10px;
                margin: -5px 0;
                border-radius: 5px;
            }
        """)

        self.status_label = QLabel("Status: Disabled", self)
        self.status_label.setStyleSheet("color: red; font-size: 14px;")
        layout.addWidget(self.status_label)

        self.chat_file_label = QLabel("Log File: Not Selected", self)
        layout.addWidget(self.chat_file_label)

        self.select_chat_file_button = QPushButton("Select Log File", self)
        self.select_chat_file_button.clicked.connect(self.select_chat_file)
        layout.addWidget(self.select_chat_file_button)

        self.sound_file_label = QLabel("Sound File: Not Selected", self)
        layout.addWidget(self.sound_file_label)

        self.select_sound_file_button = QPushButton("Select Sound File", self)
        self.select_sound_file_button.clicked.connect(self.select_sound_file)
        layout.addWidget(self.select_sound_file_button)

        self.volume_label = QLabel("Volume: 100", self)
        layout.addWidget(self.volume_label)

        self.volume_slider = QSlider(Qt.Orientation.Horizontal, self)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(100)
        self.volume_slider.valueChanged.connect(self.adjust_volume)
        layout.addWidget(self.volume_slider)

        self.enable_button = QPushButton("Enable", self)
        self.enable_button.clicked.connect(self.enable_monitoring)
        layout.addWidget(self.enable_button)

        self.disable_button = QPushButton("Disable", self)
        self.disable_button.clicked.connect(self.disable_monitoring)
        layout.addWidget(self.disable_button)

        self.init_tray()

    def init_tray(self):
        def on_quit():
            self.chat_monitor.stop_monitoring()
            self.tray_icon.stop()
            QApplication.quit()

        def on_show_window():
            self.bring_to_foreground()

        menu = Menu(MenuItem("Show Window", on_show_window), MenuItem("Quit", on_quit))
        icon_image = Image.new("RGB", (64, 64), "black")
        draw = ImageDraw.Draw(icon_image)
        draw.rectangle((16, 16, 48, 48), fill="white")
        self.tray_icon = Icon("PoE2 Chat Alert", icon_image, menu=menu)
        self.tray_icon.run_detached()

    def bring_to_foreground(self):
        self.showNormal()
        self.activateWindow()

    def closeEvent(self, event):
        self.chat_monitor.stop_monitoring()
        self.tray_icon.stop()
        QApplication.quit()

    def changeEvent(self, event):
        """Handle the minimize button (_) to minimize to the tray."""
        if event.type() == QEvent.Type.WindowStateChange:
            if self.isMinimized():
                self.minimize_to_tray()
                event.ignore()  # Prevent the default minimize behavior

    def minimize_to_tray(self):
        self.hide()

    def select_chat_file(self):
        chat_file, _ = QFileDialog.getOpenFileName(self, "Select Log File")
        if chat_file:
            self.chat_monitor.chat_file = chat_file
            self.chat_file_label.setText(f"Log File: {os.path.basename(chat_file)}")
            config = load_config()
            config["chat_file"] = chat_file
            save_config(config)

    def select_sound_file(self):
        sound_file, _ = QFileDialog.getOpenFileName(self, "Select Sound File", "", "Audio Files (*.mp3 *.wav)")
        if sound_file:
            self.chat_monitor.sound_file = sound_file
            self.sound_file_label.setText(f"Sound File: {os.path.basename(sound_file)}")
            self.chat_monitor.load_notification_sound()
            config = load_config()
            config["sound_file"] = sound_file
            save_config(config)

    def enable_monitoring(self):
        self.chat_monitor.start_monitoring()
        self.status_label.setText("Status: Enabled")
        self.status_label.setStyleSheet("color: green;")

    def disable_monitoring(self):
        self.chat_monitor.stop_monitoring()
        self.status_label.setText("Status: Disabled")
        self.status_label.setStyleSheet("color: red;")

    def adjust_volume(self, value):
        volume = value / 100
        self.chat_monitor.set_volume(volume)
        self.volume_label.setText(f"Volume: {value}")
        config = load_config()
        config["volume"] = value
        save_config(config)


def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as file:
                return json.load(file)
        except (json.JSONDecodeError, IOError):
            pass
    return {"chat_file": None, "sound_file": None, "volume": 100}


def save_config(config):
    try:
        with open(CONFIG_FILE, "w") as file:
            json.dump(config, file, indent=4)
    except IOError:
        pass


if __name__ == "__main__":
    server_address = ("127.0.0.1", 65432)
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind(server_address)
        server_socket.listen(1)

        app = QApplication([])
        chat_monitor = PoEChatMonitor()
        window = MainWindow(chat_monitor)
        window.show()

        def focus_listener():
            while True:
                conn, _ = server_socket.accept()
                conn.close()
                window.bring_to_foreground()

        threading.Thread(target=focus_listener, daemon=True).start()
        app.exec()

    except OSError:
        try:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect(server_address)
            client_socket.close()
        except ConnectionRefusedError:
            pass
        sys.exit()


# Nabooru